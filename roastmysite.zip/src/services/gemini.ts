import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export type HeatLevel = "gentle" | "honest" | "gordon";

export interface RoastResult {
  roast: string;
  tips: string[];
  cms?: string;
  score: number;
}

export async function generateRoast(url: string, heat: HeatLevel): Promise<RoastResult> {
  const model = "gemini-3-flash-preview";
  
  const systemInstructions = {
    gentle: "You are a kind, supportive design mentor. Your roasts are more like 'gentle nudges'. Be constructive and soft.",
    honest: "You are a professional, no-nonsense web developer. You tell it like it is, but with respect. Focus on UX and performance.",
    gordon: "You are the Gordon Ramsay of web design. You are brutally honest, loud (in text), and hilarious. Use creative insults but keep it about the website design and UX."
  };

  const prompt = `Analyze this website: ${url}. 
  1. Give a ${heat} roast of the design, copy, and user experience.
  2. Provide 3-5 genuinely useful, actionable improvement tips.
  3. Detect if it uses a common CMS like WordPress, Elementor, Wix, or Squarespace and comment on it.
  4. Give a 'Design Score' from 0 to 100.
  
  Return the result in JSON format.`;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      systemInstruction: systemInstructions[heat],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          roast: { type: Type.STRING, description: "The humorous roast text." },
          tips: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Actionable improvement tips."
          },
          cms: { type: Type.STRING, description: "Detected CMS or 'Custom'." },
          score: { type: Type.NUMBER, description: "Design score from 0-100." }
        },
        required: ["roast", "tips", "score"]
      },
      tools: [{ urlContext: {} }]
    }
  });

  try {
    return JSON.parse(response.text || "{}") as RoastResult;
  } catch (e) {
    console.error("Failed to parse AI response", e);
    throw new Error("The AI got too excited and forgot how to speak JSON. Try again!");
  }
}
