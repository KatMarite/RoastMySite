import React, { useState, useEffect, useCallback, Component } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Flame, Info, ExternalLink, Share2, Award, AlertTriangle, RefreshCw, Zap, LogIn, LogOut, User as UserIcon, Globe } from 'lucide-react';
import { generateRoast, RoastResult, HeatLevel } from './services/gemini';
import { 
  auth, db, googleProvider, signInWithPopup, signOut, onAuthStateChanged, User,
  collection, doc, setDoc, query, where, orderBy, limit, onSnapshot, serverTimestamp,
  OperationType, handleFirestoreError, Timestamp
} from './firebase';

// Error Boundary Component
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public state: ErrorBoundaryState = { hasError: false, error: null };
  public props: ErrorBoundaryProps;

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.props = props;
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-neutral-950 flex items-center justify-center p-6 text-center">
          <div className="max-w-md space-y-6">
            <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center mx-auto">
              <AlertTriangle className="w-8 h-8 text-red-500" />
            </div>
            <h1 className="text-2xl font-black text-white uppercase tracking-tighter">Something went wrong</h1>
            <p className="text-neutral-400 text-sm leading-relaxed">
              {this.state.error?.message?.startsWith('{') 
                ? "A database error occurred. Please try again later."
                : (this.state.error?.message || "An unexpected error occurred.")}
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="px-8 py-3 bg-white text-black font-bold rounded-xl uppercase text-sm tracking-widest hover:bg-orange-500 hover:text-white transition-all"
            >
              Reload App
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function RoastApp() {
  const [user, setUser] = useState<User | null>(null);
  const [url, setUrl] = useState('');
  const [heat, setHeat] = useState<HeatLevel>('honest');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<RoastResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hallOfShame, setHallOfShame] = useState<any[]>([]);
  const [isAuthReady, setIsAuthReady] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
      if (currentUser) {
        // Sync user profile to Firestore
        const userRef = doc(db, 'users', currentUser.uid);
        setDoc(userRef, {
          displayName: currentUser.displayName,
          email: currentUser.email,
          photoURL: currentUser.photoURL,
          role: 'user'
        }, { merge: true }).catch(e => handleFirestoreError(e, OperationType.WRITE, `users/${currentUser.uid}`));
      }
    });
    return () => unsubscribe();
  }, []);

  // Hall of Shame Listener
  useEffect(() => {
    if (!isAuthReady) return;

    const q = query(
      collection(db, 'roasts'),
      where('isPublic', '==', true),
      orderBy('createdAt', 'desc'),
      limit(10)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const roasts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setHallOfShame(roasts);
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'roasts');
    });

    return () => unsubscribe();
  }, [isAuthReady]);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: any) {
      setError("Login failed. Please try again.");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err: any) {
      setError("Logout failed.");
    }
  };

  const handleRoast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    
    setLoading(true);
    setError(null);
    setResult(null);
    
    try {
      const roastResult = await generateRoast(url, heat);
      setResult(roastResult);

      // Save to Firestore if user is logged in
      if (user) {
        const roastId = `${Date.now()}_${user.uid}`;
        await setDoc(doc(db, 'roasts', roastId), {
          ...roastResult,
          url,
          heat,
          authorId: user.uid,
          authorName: user.displayName,
          createdAt: serverTimestamp(),
          isPublic: true // Default to public for now
        });
      }
    } catch (err: any) {
      setError(err.message || "Something went wrong. The AI is probably laughing too hard.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans selection:bg-orange-500 selection:text-white">
      {/* Background Glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-orange-900/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-red-900/20 blur-[120px] rounded-full" />
      </div>

      {/* Nav */}
      <nav className="relative z-20 flex items-center justify-between px-6 py-6 max-w-7xl mx-auto">
        <div className="flex items-center gap-2 font-black tracking-tighter text-xl italic">
          <Flame className="w-6 h-6 text-orange-500" />
          ROASTMY<span className="text-orange-500">SITE</span>
        </div>
        <div className="flex items-center gap-4">
          {user ? (
            <div className="flex items-center gap-4">
              <div className="hidden md:flex flex-col items-end">
                <span className="text-xs font-bold text-white">{user.displayName}</span>
                <span className="text-[10px] text-neutral-500 uppercase tracking-widest">Roasted {hallOfShame.filter(r => r.authorId === user.uid).length} sites</span>
              </div>
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.displayName || ''} className="w-10 h-10 rounded-full border border-neutral-800" referrerPolicy="no-referrer" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center">
                  <UserIcon className="w-5 h-5 text-neutral-500" />
                </div>
              )}
              <button onClick={handleLogout} className="p-2 text-neutral-500 hover:text-white transition-colors">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <button 
              onClick={handleLogin}
              className="flex items-center gap-2 px-4 py-2 bg-white text-black rounded-xl text-sm font-bold hover:bg-orange-500 hover:text-white transition-all"
            >
              <LogIn className="w-4 h-4" />
              Login
            </button>
          )}
        </div>
      </nav>

      <main className="relative z-10 max-w-4xl mx-auto px-6 py-12">
        {/* Header */}
        <header className="text-center mb-16">
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-6xl md:text-8xl font-black tracking-tighter mb-4 bg-gradient-to-b from-white to-neutral-500 bg-clip-text text-transparent"
          >
            ROAST MY SITE
          </motion.h1>
          <motion.p 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="text-neutral-400 text-lg md:text-xl max-w-xl mx-auto"
          >
            The AI-powered landing page critic. Get brutally roasted, then genuinely helped.
          </motion.p>
        </header>

        {/* Input Form */}
        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-neutral-900/50 border border-neutral-800 p-8 rounded-3xl backdrop-blur-xl mb-12"
        >
          <form onSubmit={handleRoast} className="space-y-8">
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-widest text-neutral-500 ml-1">Website URL</label>
              <div className="relative">
                <input 
                  type="url" 
                  placeholder="https://your-awesome-site.com"
                  required
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="w-full bg-neutral-950 border border-neutral-800 rounded-2xl px-6 py-4 text-lg focus:outline-none focus:border-orange-500/50 transition-colors"
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-600">
                  <Globe className="w-5 h-5" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <label className="text-xs font-bold uppercase tracking-widest text-neutral-500 ml-1">Heat Level</label>
              <div className="grid grid-cols-3 gap-4">
                {(['gentle', 'honest', 'gordon'] as HeatLevel[]).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setHeat(level)}
                    className={`
                      relative px-4 py-3 rounded-xl text-sm font-bold uppercase tracking-tight transition-all
                      ${heat === level 
                        ? 'bg-orange-500 text-white shadow-[0_0_20px_rgba(249,115,22,0.3)]' 
                        : 'bg-neutral-950 text-neutral-500 border border-neutral-800 hover:border-neutral-700'}
                    `}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-white text-black font-black py-5 rounded-2xl text-xl uppercase tracking-tighter hover:bg-orange-500 hover:text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 group"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-6 h-6 animate-spin" />
                  ROASTING...
                </>
              ) : (
                <>
                  ROAST ME
                  <Zap className="w-6 h-6 group-hover:fill-current" />
                </>
              )}
            </button>
            {!user && (
              <p className="text-center text-neutral-500 text-xs font-bold uppercase tracking-widest">
                Login to save your roasts to the Hall of Shame
              </p>
            )}
          </form>
        </motion.div>

        {/* Error Message */}
        <AnimatePresence>
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-red-500/10 border border-red-500/20 text-red-500 p-4 rounded-2xl mb-8 flex items-center gap-3"
            >
              <AlertTriangle className="w-5 h-5 shrink-0" />
              <p className="text-sm font-medium">{error}</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Results */}
        <AnimatePresence>
          {result && (
            <motion.div 
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-8"
            >
              {/* Score Card */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2 bg-neutral-900/50 border border-neutral-800 p-8 rounded-3xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                    <Award className="w-32 h-32" />
                  </div>
                  <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-500 mb-6">The Roast</h3>
                  <p className="text-2xl md:text-3xl font-medium leading-tight italic text-neutral-100">
                    "{result.roast}"
                  </p>
                  {result.cms && (
                    <div className="mt-8 inline-flex items-center gap-2 px-3 py-1 bg-neutral-800 rounded-full text-xs font-bold text-neutral-400">
                      <Info className="w-3 h-3" />
                      CMS: {result.cms}
                    </div>
                  )}
                </div>

                <div className="bg-orange-500 p-8 rounded-3xl flex flex-col items-center justify-center text-center">
                  <h3 className="text-xs font-bold uppercase tracking-widest text-orange-950/60 mb-2">Design Score</h3>
                  <div className="text-8xl font-black text-white tracking-tighter">
                    {result.score}
                  </div>
                  <div className="text-orange-950/60 font-bold uppercase text-xs tracking-widest mt-2">out of 100</div>
                </div>
              </div>

              {/* Tips Card */}
              <div className="bg-neutral-900/50 border border-neutral-800 p-8 rounded-3xl">
                <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-500 mb-8 flex items-center gap-2">
                  <Award className="w-4 h-4" />
                  Redemption Arc: Actionable Tips
                </h3>
                <div className="grid grid-cols-1 gap-4">
                  {result.tips.map((tip, i) => (
                    <div key={i} className="flex gap-4 p-4 bg-neutral-950/50 rounded-2xl border border-neutral-800/50">
                      <div className="w-8 h-8 bg-orange-500/10 border border-orange-500/20 rounded-lg flex items-center justify-center text-orange-500 font-bold shrink-0">
                        {i + 1}
                      </div>
                      <p className="text-neutral-300 leading-relaxed">{tip}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap gap-4 justify-center pt-4">
                <button className="flex items-center gap-2 px-6 py-3 bg-neutral-800 hover:bg-neutral-700 rounded-xl text-sm font-bold transition-colors">
                  <Share2 className="w-4 h-4" />
                  Share Roast
                </button>
                <button 
                  onClick={() => {
                    setResult(null);
                    setUrl('');
                  }}
                  className="flex items-center gap-2 px-6 py-3 border border-neutral-800 hover:bg-neutral-900 rounded-xl text-sm font-bold transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  Roast Another
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hall of Shame */}
        <section className="mt-32 border-t border-neutral-900 pt-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-black tracking-tight uppercase italic">Hall of Shame</h2>
            <div className="flex items-center gap-2 text-neutral-500 text-xs font-bold uppercase tracking-widest">
              <Zap className="w-3 h-3 text-orange-500" />
              Recent Roasts
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {hallOfShame.length > 0 ? (
              hallOfShame.map((roast) => (
                <motion.div 
                  key={roast.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-neutral-900/30 border border-neutral-800 p-6 rounded-2xl hover:border-neutral-700 transition-colors group"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center text-[10px] font-black text-white">
                        {roast.score}
                      </div>
                      <span className="text-xs font-bold text-neutral-400 truncate max-w-[150px]">{roast.url}</span>
                    </div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-neutral-600">{roast.heat}</span>
                  </div>
                  <p className="text-sm text-neutral-300 line-clamp-3 italic mb-4">"{roast.roast}"</p>
                  <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-neutral-500">
                    <span>By {roast.authorName || 'Anonymous'}</span>
                    <span>{roast.createdAt?.toDate?.()?.toLocaleDateString() || 'Just now'}</span>
                  </div>
                </motion.div>
              ))
            ) : (
              [1, 2, 3, 4].map(i => (
                <div key={i} className="bg-neutral-900/30 border border-neutral-800 p-6 rounded-2xl animate-pulse">
                  <div className="h-4 w-2/3 bg-neutral-800 rounded mb-4" />
                  <div className="h-12 w-full bg-neutral-800 rounded mb-4" />
                  <div className="h-3 w-1/2 bg-neutral-800 rounded" />
                </div>
              ))
            )}
          </div>
        </section>
      </main>

      <footer className="relative z-10 py-10 border-t border-neutral-900 text-center text-neutral-600 text-xs uppercase tracking-[0.2em]">
        &copy; 2026 RoastMySite &bull; Powered by Gemini & Firebase
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <RoastApp />
    </ErrorBoundary>
  );
}
